package com.code.aon.registry;

public interface IRegistry {

	public Registry getRegistry();
	public void setRegistry(Registry registry);
}
