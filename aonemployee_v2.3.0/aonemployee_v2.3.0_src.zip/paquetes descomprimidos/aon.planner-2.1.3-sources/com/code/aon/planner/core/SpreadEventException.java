/**
 * 
 */
package com.code.aon.planner.core;

import com.code.aon.common.AonException;

/**
 * @author Consulting & Development. I�aki Ayerbe - 04/10/2007
 *
 */
public class SpreadEventException extends AonException {

	/**
	 * @param message
	 */
	public SpreadEventException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
