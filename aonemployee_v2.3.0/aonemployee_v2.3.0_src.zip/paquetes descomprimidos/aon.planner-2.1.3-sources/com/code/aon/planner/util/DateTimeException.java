package com.code.aon.planner.util;

public class DateTimeException extends Exception {

	private static final long serialVersionUID = 530469921817518019L;

	public DateTimeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
