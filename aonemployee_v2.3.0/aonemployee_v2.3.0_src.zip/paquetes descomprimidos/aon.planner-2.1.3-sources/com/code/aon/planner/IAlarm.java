/*
 * Created on 18-nov-2005
 *
 */
package com.code.aon.planner;

public interface IAlarm {

    void notice();
}
