package com.code.aon.ui.report;

import java.util.Map;

public interface IReportDynamicParamsProvider {

	public Map<String,Object> getDynamicParamsMap();
	
}
