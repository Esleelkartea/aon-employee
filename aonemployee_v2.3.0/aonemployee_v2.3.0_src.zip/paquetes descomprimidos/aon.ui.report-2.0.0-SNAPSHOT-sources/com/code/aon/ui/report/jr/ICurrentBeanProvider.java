package com.code.aon.ui.report.jr;

public interface ICurrentBeanProvider {
	public Object getCurrentBean();
}

