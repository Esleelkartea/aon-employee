package com.code.aon.config;


public interface IScopable {
	
	public Scope getScope();
	public void setScope(Scope scope);

}
