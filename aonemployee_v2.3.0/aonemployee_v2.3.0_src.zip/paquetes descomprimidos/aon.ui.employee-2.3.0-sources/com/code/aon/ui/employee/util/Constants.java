/**
 * 
 */
package com.code.aon.ui.employee.util;

/**
 * @author Consulting & Development. I�aki Ayerbe - 15/10/2007
 *
 */
public interface Constants {

	String BLANK_STRING = " ";
	String EMPTY_STRING = "";
	String APPLICATION_BUNDLE_BASE_NAME = "appBundle";

}
