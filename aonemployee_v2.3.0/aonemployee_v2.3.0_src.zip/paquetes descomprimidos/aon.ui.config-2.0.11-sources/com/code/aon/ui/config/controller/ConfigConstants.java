package com.code.aon.ui.config.controller;

public class ConfigConstants {

	// ************************************************************
	// BEAN
	// ************************************************************
	public static final String USER = "user";
	public static final String USER_SCOPE = "userScope";
	public static final String USER_WORK_GROUP = "userWorkGroup";
	public static final String WORK_GROUP = "workGroup";
	public static final String SCOPE = "scope";
	public static final String USER_UTILS = "userUtils";
	
}
